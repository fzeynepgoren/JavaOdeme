public class Baglam
{
    private OdemeYontemi odemeYontemi ;
    public void setOdemeYontemi( OdemeYontemi odemeYontemi)
    {
        this.odemeYontemi= odemeYontemi;
    }
    public void odemeyiTamamla(int i, double tutar)
    {
        odemeYontemi.OdemeYap(tutar);
    }
}
