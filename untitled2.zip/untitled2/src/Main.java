public class Main {
    public static void main(String[] args) {
        Baglam baglam = new Baglam();
        OdemeYontemi oyl = new KrediKartiOdeme();
        baglam.setOdemeYontemi(oyl);
        baglam.odemeyiTamamla(275, 68);
    }

}
