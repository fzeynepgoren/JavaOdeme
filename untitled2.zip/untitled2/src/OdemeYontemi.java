public interface OdemeYontemi
{
    public void OdemeYap(double tutar);

}
