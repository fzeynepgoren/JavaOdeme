public class BankaTransferiOdeme implements OdemeYontemi
{
    @Override
    public void OdemeYap(double tutar) {

    }
}
