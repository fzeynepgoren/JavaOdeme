public class KrediKartiOdeme implements OdemeYontemi

{
    @Override
    public void OdemeYap(double tutar) {

    }
}
