public class PaypalOdeme implements OdemeYontemi
{
    @Override
    public void OdemeYap(double tutar) {

    }
}
